
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'nitoc',
  applicationName: 'serverless-udagram-app',
  appUid: '8cPTKPZXkC8ZdKf3P6',
  orgUid: '0293c5c1-1807-4fa4-b723-c2577bd25660',
  deploymentUid: '1d12fdc3-5da2-446f-9a7c-a456188581de',
  serviceName: 'serverless-udagram-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udagram-app-dev-GetGroups', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getGroups.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}